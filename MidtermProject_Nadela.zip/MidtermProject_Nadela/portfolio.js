// Modal Functionality
function openModal(title, result) {
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-result').textContent = result;
    document.getElementById('result-modal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('result-modal').style.display = 'none';
}

// Portfolio Functions with Modal Display
function showTemperatureConverter() {
    let choice = prompt("Enter 1 to convert Celsius to Fahrenheit, or 2 for Fahrenheit to Celsius:");
    let result;
    if (choice === "1") {
        let celsius = prompt("Enter temperature in Celsius:");
        celsius = parseFloat(celsius);
        if (isNaN(celsius)) return openModal("Temperature Converter", "Please enter a valid number!");
        let fahrenheit = (celsius * 9/5) + 32;
        result = `${celsius}°C is ${fahrenheit.toFixed(2)}°F`;
    } else if (choice === "2") {
        let fahrenheit = prompt("Enter temperature in Fahrenheit:");
        fahrenheit = parseFloat(fahrenheit);
        if (isNaN(fahrenheit)) return openModal("Temperature Converter", "Please enter a valid number!");
        let celsius = (fahrenheit - 32) * 5/9;
        result = `${fahrenheit}°F is ${celsius.toFixed(2)}°C`;
    } else {
        result = "Invalid choice! Please enter 1 or 2.";
    }
    openModal("Temperature Converter", result);
}

function showLongerWord() {
    let word1 = prompt("Enter a word:");
    let word2 = prompt("Enter another word:");
    if (!word1 || !word2) return openModal("The Longer Word", "Please enter valid words!");
    let longerWord = word1.length > word2.length ? word1 :
                    word2.length > word1.length ? word2 :
                    `Both words are of equal length: ${word1} and ${word2}`;
    openModal("The Longer Word", `The longer word is: ${longerWord}`);
}

function showBirthstone() {
    let month = parseInt(prompt("Enter your birth month (1-12):"));
    const birthstones = ["Garnet", "Amethyst", "Aquamarine", "Diamond", "Emerald", "Alexandrite & Pearl",
                       "Ruby", "Peridot", "Sapphire", "Opal & Tourmaline", "Citrine & Topaz", "Blue Zircon, Turquoise, & Turquoise"];
    if (isNaN(month) || month < 1 || month > 12) {
        openModal("Know My Birthstone", "Invalid month! Please enter a number between 1 and 12.");
    } else {
        openModal("Know My Birthstone", `Your birthstone is: ${birthstones[month - 1]}`);
    }
}

function showBasicOperators() {
    let num1 = parseFloat(prompt("Enter the first number:"));
    let num2 = parseFloat(prompt("Enter the second number:"));
    if (isNaN(num1) || isNaN(num2)) return openModal("Basic Operators", "Please enter valid numbers!");
    let operation = prompt("Choose an operation: 1 for +, 2 for -, 3 for *, 4 for /");
    let result;
    switch (operation) {
        case "1": result = `${num1} + ${num2} = ${(num1 + num2).toFixed(2)}`; break;
        case "2": result = `${num1} - ${num2} = ${(num1 - num2).toFixed(2)}`; break;
        case "3": result = `${num1} * ${num2} = ${(num1 * num2).toFixed(2)}`; break;
        case "4": 
            if (num2 === 0) result = "Error: Division by zero!";
            else result = `${num1} / ${num2} = ${(num1 / num2).toFixed(2)}`;
            break;
        default: result = "Invalid operation!";
    }
    openModal("Basic Operators", result);
}

function showComputeAcceleration() {
    let initial_velocity = parseFloat(prompt("Enter initial velocity (m/s):"));
    let final_velocity = parseFloat(prompt("Enter final velocity (m/s):"));
    let delta_time = parseFloat(prompt("Enter elapsed time (s):"));
    if (isNaN(initial_velocity) || isNaN(final_velocity) || isNaN(delta_time)) {
        openModal("Compute for Acceleration", "Please enter valid numbers!");
    } else if (delta_time === 0) {
        openModal("Compute for Acceleration", "Error: Time cannot be zero!");
    } else {
        let acceleration = (final_velocity - initial_velocity) / delta_time;
        openModal("Compute for Acceleration", `The acceleration is: ${acceleration.toFixed(2)} m/s²`);
    }
}