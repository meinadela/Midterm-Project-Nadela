// Enhanced Floating Animation with My Melody, Hearts, Bows, and Sparkles
function createMyMelodyAndSparkles() {
    const myMelodyContainer = document.getElementById('my-melody-bg');
    // My Melody
    for (let i = 0; i < 15; i++) {
        const myMelody = document.createElement('div');
        myMelody.classList.add('my-melody');
        myMelody.style.left = Math.random() * 100 + 'vw';
        myMelody.style.animationDuration = Math.random() * 5 + 7 + 's';
        myMelody.style.animationDelay = Math.random() * 5 + 's';
        myMelodyContainer.appendChild(myMelody);
    }
    // Hearts
    for (let i = 0; i < 10; i++) {
        const heart = document.createElement('div');
        heart.classList.add('heart');
        heart.style.left = Math.random() * 100 + 'vw';
        heart.style.animationDuration = Math.random() * 4 + 6 + 's';
        heart.style.animationDelay = Math.random() * 5 + 's';
        myMelodyContainer.appendChild(heart);
    }
    // Bows
    for (let i = 0; i < 10; i++) {
        const bow = document.createElement('div');
        bow.classList.add('bow');
        bow.style.left = Math.random() * 100 + 'vw';
        bow.style.animationDuration = Math.random() * 4 + 5 + 's';
        bow.style.animationDelay = Math.random() * 5 + 's';
        myMelodyContainer.appendChild(bow);
    }
    // Sparkles
    for (let i = 0; i < 15; i++) {
        const sparkle = document.createElement('div');
        sparkle.classList.add('sparkle');
        sparkle.style.left = Math.random() * 100 + 'vw';
        sparkle.style.animationDuration = Math.random() * 4 + 4 + 's';
        sparkle.style.animationDelay = Math.random() * 5 + 's';
        myMelodyContainer.appendChild(sparkle);
    }
}
createMyMelodyAndSparkles();

// Homepage Carousel Functionality (Unchanged)
let currentSlide = 0;
const slides = document.querySelectorAll('#carousel-images img');
const totalSlides = slides.length;

function updateCarousel() {
    const carouselImages = document.getElementById('carousel-images');
    if (carouselImages) {
        carouselImages.style.transform = `translateX(-${currentSlide * 100}%)`;
    }
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % totalSlides;
    updateCarousel();
}

function prevSlide() {
    currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
    updateCarousel();
}

if (slides.length > 0) {
    setInterval(nextSlide, 5000);
}

// Back to Top Functionality (Unchanged)
window.onscroll = function() {
    const backToTop = document.getElementById('back-to-top');
    if (backToTop) {
        if (document.body.scrollTop > 200 || document.documentElement.scrollTop > 200) {
            backToTop.style.display = 'block';
        } else {
            backToTop.style.display = 'none';
        }
    }
};

function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}