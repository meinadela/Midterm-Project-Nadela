// Favorites Functions
function toggleLike(element, counterId) {
    element.classList.toggle('liked');
    const counter = document.getElementById(counterId);
    let count = parseInt(counter.textContent || 0); // Default to 0 if counter doesn't exist yet
    counter.textContent = element.classList.contains('liked') ? count + 1 : count - 1;
}

function addComment(button) {
    let commentInput = button.previousElementSibling;
    let commentText = commentInput.value.trim();
    
    if (commentText !== "") {
        let commentList = button.parentElement.nextElementSibling;
        let newComment = document.createElement("li");
        newComment.textContent = commentText;
        commentList.appendChild(newComment);
        commentInput.value = "";
    }
}